﻿
namespace DefiningClasses
{

    public class Person
    {
        string name;
        int age;

        public string Name { get; set; }
        public int Age { get; set; }
    }
}

